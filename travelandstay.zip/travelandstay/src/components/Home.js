import React from 'react';

function Home() {
  return (
    <main style={{ padding: '20px' }}>
      <h2>Benvenuti in Travel&Stay</h2>
      <p>
        Offriamo servizi di co-hosting per appartamenti turistici a Ragusa, con gestione su Airbnb, Booking e privatamente. Soggiorni eleganti, puliti e multilingue.
      </p>
      <p>Lingue disponibili: Italiano, Inglese</p>
    </main>
  );
}

export default Home;