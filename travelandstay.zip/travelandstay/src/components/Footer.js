import React from 'react';

function Footer() {
  return (
    <footer style={{ padding: '20px', backgroundColor: '#f0f0f0' }}>
      <p>Contatti: travelandstay@proton.me | +3519355847</p>
      <p>Via Salina 12, Ragusa 97100</p>
    </footer>
  );
}

export default Footer;