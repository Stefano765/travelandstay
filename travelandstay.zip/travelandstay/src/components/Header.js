import React from 'react';

function Header() {
  return (
    <header style={{ padding: '20px', backgroundColor: '#f8f8f8' }}>
      <h1>Travel&Stay</h1>
      <p>Co-hosting e Vacation Rentals a Ragusa</p>
    </header>
  );
}

export default Header;